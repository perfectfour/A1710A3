﻿using System;
using System.Collections.Generic;

namespace BoothModel.Models
{
    public partial class RbacPower
    {
        public Guid Id { get; set; }
        public string PowerName { get; set; }
    }
}
