﻿using System;

namespace IBoothDataAccess
{
    public interface IBoothManageContext
    {
        //int SaveChanges();

    }
}
